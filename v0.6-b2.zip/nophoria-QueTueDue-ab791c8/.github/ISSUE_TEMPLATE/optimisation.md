---
name: Optimisation
about: Is my code formatted weirdly? Please tell me! (I promise I wont bite :3)
title: ''
labels: ''
assignees: ''

---

**Type of optimisation**
Could I improve a function? Have I completely forgotten about consistency?

**Snippet of code**
Where did this occur?

**Potential solutions**
How could this be fixed (if you know how to)?
